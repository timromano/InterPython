import amaze

__author__ = 'Reindert-Jan Ekker'

if __name__ == "__main__":
    m = amaze.kruskal_generate(10,10)
    print(m)
