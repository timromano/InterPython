"""
amaze.demo module
~~~~~~~~~~~~~~~~~


Some information about this module here.
"""

from .tkdemo import MazeDemo

__author__ = 'Reindert-Jan Ekker'
